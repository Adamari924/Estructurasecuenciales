/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estructuras.secuenciales;
import java.util.Scanner;

/**
 *
 * @author Hp
 */
public class EstructurasSecuenciales {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola Mundo mi nombre es Adamari");
        int n1=9,n2=2,suma,resta,multi,divi;
        
        //suma
        suma=n1+n2;
        //resta
        resta=n1-n2;
        //multi
        multi=n1*n2;
        //division
        divi=n1/n2;
        
        System.out.println(suma+"/n");
        System.out.println(resta+"/n");
        System.out.println(multi+"/n");
        System.out.println(divi+"/n");
        
        
         double Area, Base, Altura;
        
        System.out.println("Ingresa la altura....");
        Scanner Captura=new Scanner(System.in);
        Altura=Captura.nextDouble();
        
        System.out.println("Ingresa la Base");
        Scanner Captura1=new Scanner(System.in);
        Base=Captura1.nextDouble();
        
        Area=(Base*Altura)/2;
        
        System.out.println("El area del triangulo es..."+Area);
        
        Scanner teclado=new Scanner(System.in);
        int horas;
        double sueldohora=123.22, sueldo;
        String nombre;
        System.out.println("Nombre del empleado: ");
        nombre=teclado.nextLine();
        System.out.println("Horas trabajadas en la semana: ");
        horas=teclado.nextInt();
        sueldo=sueldohora*horas;
        System.out.println("El empleado "+nombre+" trabajo "+horas+" horas a la semana, su sueldo es de: "+sueldo);
        
        


        
    }
    
}
