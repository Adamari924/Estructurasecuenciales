/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.util.Scanner;

/**
 *
 * @author Hp
 */
public class Codigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner ingresar=new Scanner(System.in);
    System.out.println("Ingrese un numero");
    var dato=ingresar.nextInt();
    
    if(dato<10 && dato>0){
        System.out.println("Hola mundo");
    }
    System.out.println("Ingrese otro numero:");
    var num=ingresar.nextInt();
    if (num<0) {
        System.out.println("Negativo");
    }else{
        System.out.println("Positivo");
    }
    System.out.println("Ingrese el primer numero");
    var num1=ingresar.nextInt();
    System.out.println("Ingrese el segundo numero");
    var num2=ingresar.nextInt();
    System.out.println("Ingrese el tercer numero");
    var num3=ingresar.nextInt();
    if (num1==num2&&num2==num3){
    System.out.println("Todos los numeros son iguales");
    }else if (num1>num2&&num1>num3){
    System.out.println("El numero mayor es: "+num1);
    }else if (num2>num1&&num2>num3){
    System.out.println("El numero mayor es: "+num2);
    }else{
        System.out.println("El numero mayor es: "+num3);
    }
    System.out.println("Ingrese un numero: ");
    var dia=ingresar.nextInt();
    switch (dia) {
        case 1:
            System.out.println("Lunes");
            break;
        case 2:
            System.out.println("Martes");
            break;
        case 3:
            System.out.println("Miercoles");
        case 4:
           System.out.println("Jueves");
        case 5:
            System.out.println("Viernes");
        case 6:
            System.out.println("Sabado");
        case 7:
            System.out.println("Domingo");
            break;
    }
    }

    
}
